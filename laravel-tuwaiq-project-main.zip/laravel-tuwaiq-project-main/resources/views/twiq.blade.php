@extends('layouts.app');

@section('content')
    <h1 class="text-center bg-primary text-light">
        صفحة طويق
    </h1>
@endsection
