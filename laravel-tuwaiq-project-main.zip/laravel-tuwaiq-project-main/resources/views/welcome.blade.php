@extends('layouts.app');


@section('content')
    <h1 class="p-5 text-center">
        اهلا بكم في الصفحة الرئيسية
    </h1>
@endsection
